# -*- coding: utf-8 -*-
"""
Created on Thu Sep 20 00:27:05 2012

@author: orient
"""


def main():
    """
    Test whether the PyDPI package is installed successfully.
    """
    print "Test successfully!"



if __name__=="__main__":
    
    print "Testing ......"
    main()